/* ============================================================
   RAN — Re-Orientation Advocacy of Nigeria
   Main JavaScript
   ============================================================ */

document.addEventListener('DOMContentLoaded', () => {

  // === Navbar scroll effect ===
  const nav = document.getElementById('navbar');
  const btt = document.getElementById('btt');

  window.addEventListener('scroll', () => {
    nav.classList.toggle('scrolled', scrollY > 60);
    btt.classList.toggle('show', scrollY > 600);
  });

  // === Mobile menu toggle ===
  const hamburger = document.getElementById('hamburger');
  const mobileMenu = document.getElementById('mobileMenu');

  hamburger.addEventListener('click', () => {
    mobileMenu.classList.toggle('open');
  });

  mobileMenu.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
      mobileMenu.classList.remove('open');
    });
  });

  // === Scroll reveal observer ===
  const rvEls = document.querySelectorAll('.rv, .rv-l, .rv-r, .rv-s');
  const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        e.target.classList.add('vis');
      }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -30px 0px' });

  rvEls.forEach(el => revealObserver.observe(el));

  // === Animated counters ===
  const counters = document.querySelectorAll('.counter');
  const counterObserver = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        const c = e.target;
        const target = +c.dataset.target;
        const duration = 2200;
        const start = performance.now();

        function tick(now) {
          const progress = Math.min((now - start) / duration, 1);
          const eased = 1 - Math.pow(1 - progress, 4);
          c.textContent = Math.round(eased * target);
          if (progress < 1) requestAnimationFrame(tick);
        }

        requestAnimationFrame(tick);
        counterObserver.unobserve(c);
      }
    });
  }, { threshold: 0.5 });

  counters.forEach(c => counterObserver.observe(c));

  // === Smooth anchor scrolling ===
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', e => {
      e.preventDefault();
      const target = document.querySelector(a.getAttribute('href'));
      if (target) target.scrollIntoView({ behavior: 'smooth' });
    });
  });

  // === Generate hero floating particles ===
  const particleContainer = document.getElementById('heroParticles');
  if (particleContainer) {
    for (let i = 0; i < 20; i++) {
      const p = document.createElement('div');
      p.className = 'particle';
      const size = Math.random() * 6 + 2;
      p.style.cssText = `
        width: ${size}px;
        height: ${size}px;
        left: ${Math.random() * 100}%;
        animation-duration: ${Math.random() * 15 + 10}s;
        animation-delay: ${Math.random() * 10}s;
        opacity: ${Math.random() * 0.3 + 0.1};
      `;
      particleContainer.appendChild(p);
    }
  }

  // === Hero parallax on scroll ===
  const rings = document.querySelector('.hero-rings');
  const watermark = document.querySelector('.hero-watermark');

  window.addEventListener('scroll', () => {
    const y = window.scrollY;
    if (rings) rings.style.transform = `translateY(calc(-50% + ${y * 0.15}px))`;
    if (watermark) watermark.style.transform = `translateY(calc(-50% + ${y * 0.1}px))`;
  });

  // === Back to top ===
  btt.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  // === Form handlers ===
  const memberForm = document.getElementById('membershipForm');
  if (memberForm) {
    memberForm.addEventListener('submit', e => {
      e.preventDefault();
      alert('Thank you for your interest in RAN! Your membership application has been submitted.');
      memberForm.reset();
    });
  }

  const contactForm = document.getElementById('contactForm');
  if (contactForm) {
    contactForm.addEventListener('submit', e => {
      e.preventDefault();
      alert('Thank you for contacting RAN! We will respond shortly.');
      contactForm.reset();
    });
  }

  const newsletterForm = document.getElementById('newsletterForm');
  if (newsletterForm) {
    newsletterForm.addEventListener('submit', e => {
      e.preventDefault();
      alert('You have been subscribed to the RAN newsletter!');
      newsletterForm.reset();
    });
  }

});
